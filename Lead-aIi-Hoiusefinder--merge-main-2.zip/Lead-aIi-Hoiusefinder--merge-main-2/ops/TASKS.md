# Tasks

- Bootstrap supervisor structure
