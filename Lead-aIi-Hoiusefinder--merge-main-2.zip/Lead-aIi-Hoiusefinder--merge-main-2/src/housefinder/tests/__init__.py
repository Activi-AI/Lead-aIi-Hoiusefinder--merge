"""Test suite for Housefinder"""
